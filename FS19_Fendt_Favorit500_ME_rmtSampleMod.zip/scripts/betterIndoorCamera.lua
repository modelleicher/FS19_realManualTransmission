-- by modelleicher


betterIndoorCamera = {};

function betterIndoorCamera.prerequisitesPresent(specializations)
	print("prerequisitesPresent is active");
    return true;
end;

-- new in FS19, you have to register yourself to functions otherwise they aren't called.
-- also, everything has the "on" prefix now (onLoad, onUpdate etc.)


function betterIndoorCamera.registerEventListeners(vehicleType)
	print("registerEventListeners called");
	SpecializationUtil.registerEventListener(vehicleType, "onLoad", betterIndoorCamera);
	SpecializationUtil.registerEventListener(vehicleType, "onUpdate", betterIndoorCamera);
	SpecializationUtil.registerEventListener(vehicleType, "onRegisterActionEvents", betterIndoorCamera); -- this one is used to add the actionEvents
end;

-- actionEvent stuffs.. (this one is called each time the vehicle is entered)
function betterIndoorCamera.onRegisterActionEvents(self, isActiveForInput)
	local spec = self.spec_betterIndoorCamera;
	spec.actionEvents = {}; -- needs this. Farmcon Example didn't have this. Doesn't work without this though.. 
	self:clearActionEventsTable(spec.actionEvents); -- not sure if we need to clear the table now that we just created it. I suppose you could create the table in onLoad, then it makes more sense
	
	-- add the actionEvents if vehicle is ready to have Inputs
	if self:getIsActiveForInput(true) then      
		local _, actionEventId = self:addActionEvent(spec.actionEvents, InputAction.BIC_CAMERA_SEAT_SUSPENSION_TOGGLE, self, betterIndoorCamera.BIC_CAMERA_SEAT_SUSPENSION_TOGGLE, false, true, false, true, nil);
	end;

end;

function betterIndoorCamera:BIC_CAMERA_SEAT_SUSPENSION_TOGGLE()
	print("input called");
	local spec = self.spec_betterIndoorCamera;
	
	
	setTranslation(spec.cameraTransform, 0, 10, 0);
	
	spec.cameraNodeSuspensionActive = not spec.cameraNodeSuspensionActive;
end;




function betterIndoorCamera:onLoad(savegame)
	
	self.spec_betterIndoorCamera = {};  -- creating the table where all the variables are stored in
	local spec = self.spec_betterIndoorCamera; -- this looks different to the example on the farmCon video. didn't work the other way though I assume mistake in their presentation

	
	
	-- find the right suspension, the one for the seat
	-- look for character node and parent up from there
	local characterNode = self.spec_enterable.vehicleCharacter.characterNode;
	for k, suspension in pairs (self.spec_suspensions.suspensionNodes) do
		if suspension.node == getParent(characterNode) or suspension.node == getParent(getParent(characterNode)) then
			spec.seatSuspensionNode = suspension.node;
		end;
	end;
	
	print(spec.seatSuspensionNode);
	
	--
	spec.cameraNodeSuspensionActive = false;
	
	-- find indoor camera node
	for k, camera in pairs(self.spec_enterable.cameras) do
		if camera.isInside then
			spec.insideCameraNode = camera.cameraNode;
		end;
	end;
	
	
	
	-- set up indoor camera for translations/rotations
	
	-- get parent node
	local parent = getParent(spec.insideCameraNode);
	-- DOES NOT WORK! Because camera already is unlinked from vehicle for the smoothing from Giants
	-- stupid..
	
	-- create new transform
	local cameraTransform = createTransformGroup("cameraTransform");
	print("Camera Transform: "..cameraTransform);
	print("inside camera node: "..spec.insideCameraNode);
	print("parent camera node: "..parent);
	
	-- link transform to parent
	link(parent, cameraTransform);
	
	-- set translation of cameraTransform transform
	local x, y, z = getTranslation(spec.insideCameraNode);
	setTranslation(cameraTransform, x, y, z);
	
	-- link camera to transform
	link(cameraTransform, spec.insideCameraNode);
	
	-- set translation of cameraNode to 0
	setTranslation(spec.insideCameraNode, 0, 0, 0);
	
	spec.cameraTransform = cameraTransform;

end;

function betterIndoorCamera:onUpdate(dt) 
	local spec = self.spec_betterIndoorCamera;
    
	if self:getIsActive() and spec.cameraNodeSuspensionActive then 
		

    end; 
end;





































